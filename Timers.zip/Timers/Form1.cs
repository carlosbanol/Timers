﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Timers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tmrx1.Enabled = true;
            tmrx2.Enabled = true;
            tmrx3.Enabled = true;
        }

        private void tmrx1_Tick(object sender, EventArgs e)
        {
            lblx1.Text = Convert.ToString(Convert.ToUInt32(lblx1.Text) + 2);
            if(lblx1.Text == "100")
            {
                tmrx1.Enabled = false;
            }
        }

        private void tmrx2_Tick(object sender, EventArgs e)
        {
            lblx2.Text = Convert.ToString(Convert.ToUInt32(lblx2.Text) + 3);
            if (lblx2.Text == "102")
            {
                tmrx2.Enabled = false;
            }
        }

        private void tmrx3_Tick(object sender, EventArgs e)
        {
            lblx3.Text = Convert.ToString(Convert.ToUInt32(lblx3.Text) + 5);
            if (lblx3.Text == "105")
            {
                tmrx3.Enabled = false;
            }
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            winMove winMove = new winMove();
            winMove.Show();
        }

        
    }
}
