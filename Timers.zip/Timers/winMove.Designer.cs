﻿namespace Timers
{
    partial class winMove
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.picUFO = new System.Windows.Forms.PictureBox();
            this.tmrx1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.picUFO)).BeginInit();
            this.SuspendLayout();
            // 
            // picUFO
            // 
            this.picUFO.BackgroundImage = global::Timers.Properties.Resources.ovni;
            this.picUFO.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picUFO.Location = new System.Drawing.Point(51, 26);
            this.picUFO.Name = "picUFO";
            this.picUFO.Size = new System.Drawing.Size(114, 92);
            this.picUFO.TabIndex = 0;
            this.picUFO.TabStop = false;
            this.picUFO.Click += new System.EventHandler(this.picUFO_Click);
            // 
            // tmrx1
            // 
            this.tmrx1.Enabled = true;
            this.tmrx1.Interval = 25;
            this.tmrx1.Tick += new System.EventHandler(this.tmrx1_Tick);
            // 
            // winMove
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 361);
            this.Controls.Add(this.picUFO);
            this.Name = "winMove";
            this.Text = "winMove";
            this.Load += new System.EventHandler(this.winMove_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picUFO)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picUFO;
        private System.Windows.Forms.Timer tmrx1;
    }
}