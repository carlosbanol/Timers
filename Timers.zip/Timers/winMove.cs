﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Timers
{
    public partial class winMove : Form
    {

        private bool movimiento = true;
        public winMove()
        {
            InitializeComponent();
        }

        private void picUFO_Click(object sender, EventArgs e){}

        private void winMove_Load(object sender, EventArgs e)
        {
            //picUFO.ImageLocation = Application.StartupPath + ("\\imgs\\ovni.png");
        }

        private void tmrx1_Tick(object sender, EventArgs e)
        {
            
            int x = picUFO.Location.X;
            int y = picUFO.Location.Y;

            int speed = 5;

            if (movimiento)
            {
                x += speed;

                if( x + picUFO.Width > this.ClientSize.Width )
                {
                    x = this.ClientSize.Width - picUFO.Width;
                    movimiento = false;
                }
            }
            else
            {
                x -= speed;

                if(x < 0)
                {
                    x = 0;
                    movimiento = true;
                }
            }

            picUFO.Location = new Point(x, y);
        }
    }
}
