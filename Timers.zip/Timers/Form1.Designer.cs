﻿namespace Timers
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblx1 = new System.Windows.Forms.Label();
            this.lblx2 = new System.Windows.Forms.Label();
            this.lblx3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tmrx1 = new System.Windows.Forms.Timer(this.components);
            this.tmrx2 = new System.Windows.Forms.Timer(this.components);
            this.tmrx3 = new System.Windows.Forms.Timer(this.components);
            this.btnGo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblx1
            // 
            this.lblx1.AutoSize = true;
            this.lblx1.Location = new System.Drawing.Point(140, 89);
            this.lblx1.Name = "lblx1";
            this.lblx1.Size = new System.Drawing.Size(13, 13);
            this.lblx1.TabIndex = 0;
            this.lblx1.Text = "0";
            // 
            // lblx2
            // 
            this.lblx2.AutoSize = true;
            this.lblx2.Location = new System.Drawing.Point(309, 89);
            this.lblx2.Name = "lblx2";
            this.lblx2.Size = new System.Drawing.Size(13, 13);
            this.lblx2.TabIndex = 1;
            this.lblx2.Text = "0";
            // 
            // lblx3
            // 
            this.lblx3.AutoSize = true;
            this.lblx3.Location = new System.Drawing.Point(496, 89);
            this.lblx3.Name = "lblx3";
            this.lblx3.Size = new System.Drawing.Size(13, 13);
            this.lblx3.TabIndex = 2;
            this.lblx3.Text = "0";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(276, 174);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tmrx1
            // 
            this.tmrx1.Tick += new System.EventHandler(this.tmrx1_Tick);
            // 
            // tmrx2
            // 
            this.tmrx2.Tick += new System.EventHandler(this.tmrx2_Tick);
            // 
            // tmrx3
            // 
            this.tmrx3.Tick += new System.EventHandler(this.tmrx3_Tick);
            // 
            // btnGo
            // 
            this.btnGo.Location = new System.Drawing.Point(433, 174);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(75, 23);
            this.btnGo.TabIndex = 4;
            this.btnGo.Text = "Inicio";
            this.btnGo.UseVisualStyleBackColor = true;
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 361);
            this.Controls.Add(this.btnGo);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblx3);
            this.Controls.Add(this.lblx2);
            this.Controls.Add(this.lblx1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblx1;
        private System.Windows.Forms.Label lblx2;
        private System.Windows.Forms.Label lblx3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer tmrx1;
        private System.Windows.Forms.Timer tmrx2;
        private System.Windows.Forms.Timer tmrx3;
        private System.Windows.Forms.Button btnGo;
    }
}

